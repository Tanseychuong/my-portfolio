(function () {

    const API = `${API_BASE}/api/analytics/track`;

    function detectDevice() {

        const ua = navigator.userAgent;

        if (/tablet|ipad/i.test(ua)) return "Tablet";

        if (/mobile|iphone|android/i.test(ua)) return "Mobile";

        return "Desktop";

    }

    function sendPing() {

        const payload = JSON.stringify({
            page: window.location.pathname,
            device: detectDevice(),
            duration: null
        });

        fetch(API, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: payload,
            keepalive: true
        }).catch(() => {});

    }

    // Log exactly one pageview per page load
    window.addEventListener("load", sendPing);

})();

