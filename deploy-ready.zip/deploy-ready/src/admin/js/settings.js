
const token = localStorage.getItem("token");

if (!token) {

    window.location.href = "login.html";

}


async function loadProfile() {

    try {

        const response = await fetch(`${API_BASE}/api/auth/me`, {
            headers: {
                Authorization: token
            }
        });

        if (!response.ok) return;

        const user = await response.json();

        document.getElementById("accountUsername").textContent = user.username;
        document.getElementById("accountEmail").textContent = user.email;

    } catch (error) {

        console.error(error);

    }

}

loadProfile();


const passwordForm = document.getElementById("passwordForm");
const passwordStatus = document.getElementById("passwordStatus");

passwordForm.addEventListener("submit", async (e) => {

    e.preventDefault();

    passwordStatus.textContent = "";
    passwordStatus.style.color = "";

    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {

        passwordStatus.textContent = "New passwords do not match.";
        return;

    }

    try {

        const response = await fetch(`${API_BASE}/api/auth/password`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                Authorization: token
            },
            body: JSON.stringify({
                currentPassword,
                newPassword
            })
        });

        const data = await response.json();

        if (!response.ok) {

            passwordStatus.textContent = data.message || "Failed to update password.";
            return;

        }

        passwordStatus.style.color = "#2ecc71";
        passwordStatus.textContent = "Password updated successfully.";

        passwordForm.reset();

    } catch (error) {

        console.error(error);
        passwordStatus.textContent = "Cannot connect to server.";

    }

});


document.getElementById("logout").onclick = () => {

    localStorage.removeItem("token");
    location.href = "login.html";

};
