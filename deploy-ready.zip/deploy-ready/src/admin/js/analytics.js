
const token = localStorage.getItem("token");

if (!token) {

    window.location.href = "login.html";

}


function formatDate(dateString) {

    const date = new Date(dateString);

    return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });

}


function renderBreakdownList(container, rows, labelKey) {

    if (!rows.length) {

        container.innerHTML = "<p>No data yet.</p>";
        return;

    }

    const total = rows.reduce((sum, r) => sum + r.count, 0);

    container.innerHTML = rows.map(row => {

        const pct = total ? Math.round((row.count / total) * 100) : 0;

        return `

        <div class="progress-item">

            <span>${row[labelKey]} — ${row.count}</span>

            <div class="progress">

                <div class="progress-bar" style="width:${pct}%; background: linear-gradient(90deg, #5d4634, #8a6b52);"></div>

            </div>

        </div>

        `;

    }).join("");

}


async function loadAnalytics() {

    try {

        const response = await fetch(`${API_BASE}/api/analytics`, {
            headers: {
                Authorization: token
            }
        });

        if (!response.ok) {

            document.getElementById("totalVisitors").textContent = "—";
            return;

        }

        const data = await response.json();

        document.getElementById("totalVisitors").textContent =
            data.totalVisitors || 0;

        renderBreakdownList(
            document.getElementById("deviceBreakdown"),
            data.deviceBreakdown,
            "device"
        );

        renderBreakdownList(
            document.getElementById("topPages"),
            data.topPages,
            "page"
        );

        const recentTable = document.getElementById("recentVisitors");

        recentTable.innerHTML = "";

        if (!data.recentVisitors.length) {

            recentTable.innerHTML = `<tr><td colspan="4">No visitors recorded yet.</td></tr>`;

        } else {

            data.recentVisitors.forEach(v => {

                recentTable.innerHTML += `

                <tr>

                    <td>${v.page || "—"}</td>

                    <td>${v.device || "—"}</td>

                    <td>${v.ip_address || "—"}</td>

                    <td>${formatDate(v.visited_at)}</td>

                </tr>

                `;

            });

        }

    } catch (error) {

        console.error(error);

    }

}

loadAnalytics();


document.getElementById("logout").onclick = () => {

    localStorage.removeItem("token");
    location.href = "login.html";

};
